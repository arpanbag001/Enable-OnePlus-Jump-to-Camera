# Enable Jump To Camera for OnePlus #

### This Magisk Module enables double press power button to launch camera gesture, in case it is disabled by manufacturer and replaced with Emergency call. ###

#### Instructions: ####
1. Download the module zip.
2. Flash through Magisk manager or TWRP
3. Reboot
4. Wait 1 or 2 minutes for the scripts to execute
5. Enjoy

#### Tested on: ####
OnePlus 6 running OxygenOS 5.1.11 (Android 8.1).
Magisk version: 17.1